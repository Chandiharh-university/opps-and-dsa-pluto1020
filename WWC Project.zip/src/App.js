import React, { useState } from 'react';

// Helper function to shuffle options using the Fisher-Yates algorithm
const shuffleArray = (array) => {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
};

const quizQuestions = [
  {
    question: "How many days are there in a week?",
    options: shuffleArray(["5 days", "6 days", "7 days", "8 days"]),
    answer: "7 days",
  },
  {
    question: "How many hours are there in a day?",
    options: shuffleArray(["12 hours", "24 hours", "48 hours", "72 hours"]),
    answer: "24 hours",
  },
  {
    question: "How many letters are there in the English alphabet?",
    options: shuffleArray(["24 letters", "25 letters", "26 letters", "27 letters"]),
    answer: "26 letters",
  },
  {
    question: "Rainbow consists of how many colors?",
    options: shuffleArray(["5 colours", "6 colours", "7 colours", "8 colours"]),
    answer: "7 colours",
  },
];

function App() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [userAnswer, setUserAnswer] = useState("");
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswerSubmit = () => {
    if (userAnswer === quizQuestions[currentQuestion].answer) {
      setScore(score + 1);
    }

    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setUserAnswer("");
    } else {
      setShowResult(true);
    }
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setUserAnswer("");
    setScore(0);
    setShowResult(false);
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Online Quiz System</h1>
      {!showResult ? (
        <div>
          <h2>{quizQuestions[currentQuestion].question}</h2>
          <div>
            {quizQuestions[currentQuestion].options.map((option, index) => (
              <div key={index}>
                <input
                  type="radio"
                  name="answer"
                  value={option}
                  onChange={(e) => setUserAnswer(e.target.value)}
                />
                {option}
              </div>
            ))}
          </div>
          <br />
          <button onClick={handleAnswerSubmit}>Submit</button>
        </div>
      ) : (
        <div>
          <h2>Quiz Completed</h2>
          <p>Your Score: {score} / {quizQuestions.length}</p>
          <button onClick={restartQuiz}>Restart Quiz</button>
        </div>
      )}
    </div>
  );
}

export default App;
